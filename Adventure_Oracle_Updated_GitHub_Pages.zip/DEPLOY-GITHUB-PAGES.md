# Adventure Oracle — publish on GitHub Pages

1. Sign in to https://github.com/ and create a new **public** repository named `adventure-oracle`.
2. Choose **Add file → Upload files**. Upload `index.html` and the entire `src` folder from this package. On iPhone, uploading folders is awkward; use a computer or GitHub Desktop if needed.
3. Commit the files to the `main` branch.
4. In repository **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. After deployment, open `https://YOUR-USERNAME.github.io/adventure-oracle/` in Safari.
6. Tap Share → Add to Home Screen.

The site currently loads Bootstrap, jQuery, Font Awesome, and Toastr from third-party CDNs. It therefore requires internet access for full functionality. A GitHub Pages site is public: never commit your personal savegame JSON or private account information.

This package is an independently branded adaptation of an existing open-source project. Check the original project's license and game artwork redistribution rights before public publication; do not remove legally required copyright or attribution notices. This is not an official Eatventure product.
