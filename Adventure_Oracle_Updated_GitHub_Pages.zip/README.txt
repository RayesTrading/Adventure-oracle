Adventure Oracle — unofficial Eatventure companion.
Open index.html from a web host in Safari for best results. Upload this folder to a static website host.
The prediction engine and bundled item images are derived from the publicly available 1vCian/ev project. No license file was present in the supplied archive. Preserve provenance; do not claim exclusive authorship or redistribute commercially without checking permissions.
This version removes promotional links and adds an illustrated item catalog. Predictions are not verified against current game data.
